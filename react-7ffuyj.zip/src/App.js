import React, { useState } from 'react';
import ProductList from './components/ProductList';
import Cart from './components/Cart';
import './style.css'; 
const App = () => {
    const [cart, setCart] = useState([]);

    const products = [
        { id: 1, name: 'Product 1', price: 29.99 },
        { id: 2, name: 'Product 2', price: 39.99 },
        { id: 3, name: 'Product 3', price: 49.99 },
    ];

    const addToCart = (product) => {
        setCart([...cart, product]);
    };

    const removeFromCart = (productId) => {
        setCart(cart.filter((item) => item.id !== productId));
    };

    return (
        <div className="App">
            <h1>Simple Shopping Cart</h1>
            <ProductList products={products} addToCart={addToCart} />
            <Cart cartItems={cart} removeFromCart={removeFromCart} />
        </div>
    );
};

export default App;

